# BingX Telegram Bot V7

使用方法：
1. 填好 `.env`
2. 部署至 Railway

